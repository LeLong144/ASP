﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ShopML.Models
{
    public class HangSanXuat
    {
        [DisplayName("Mã HSX")]
        public int ID { get; set; }
        [StringLength(255)]
        [Required(ErrorMessage ="Tên Hãng Sản Xuất Không Được Bỏ Trống.")]
        [DisplayName("Tên Hãng Sản Xuất")]
        public string TenHangSanXuat { get; set; }
        public ICollection<SanPham>? SanPham { get; set; }
    }
}
